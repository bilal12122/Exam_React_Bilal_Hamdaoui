const fakeElements = [
    {
        element: {
            id: 16774301,
            name: 'Element 01',
        },
    },
    {
        element: {
            id: 16774302,
            name: 'Element 02',
        },
    },
    {
        element: {
            id: 16774303,
            name: 'Elemen 03',
        },
    },
    {
        element: {
            id: 16774304,
            name: 'Element 04',
        },
    },
    {
        element: {
            id: 16774305,
            name: 'Elemen 05',
        },
    },
    {
        element: {
            id: 16774306,
            name: 'Element 06',
        },
    },
    {
        element: {
            id: 16774307,
            name: 'Element 07',
        },
    },
    {
        element: {
            id: 16774308,
            name: 'Element 08',
        },
    },
    {
        element: {
            id: 16774309,
            name: 'Elemen 09',
        },
    },
    {
        element: {
            id: 16774310,
            name: 'Element 10',
        },
    },
    {
        element: {
            id: 16774311,
            name: 'Element 11',
        },
    },
    {
        element: {
            id: 16774312,
            name: 'Elemen 12',
        },
    },
    {
        element: {
            id: 16774313,
            name: 'Element 13',
        },
    },
    {
        element: {
            id: 16774314,
            name: 'Element 14',
        },
    },
    {
        element: {
            id: 16774315,
            name: 'Elemen 15',
        },
    },
    {
        element: {
            id: 16774316,
            name: 'Element 16',
        },
    },
    {
        element: {
            id: 16774317,
            name: 'Element 17',
        },
    },
    {
        element: {
            id: 16774318,
            name: 'Element 18',
        },
    },
    {
        element: {
            id: 16774319,
            name: 'Element 19',
        },
    },
    {
        element: {
            id: 16774320,
            name: 'Elemen 20',
        },
    },
    {
        element: {
            id: 16774321,
            name: 'Element 21',
        },
    },
    {
        element: {
            id: 16774322,
            name: 'Element 22',
        },
    },
    {
        element: {
            id: 16774323,
            name: 'Elemen 23',
        },
    },
    {
        element: {
            id: 16774324,
            name: 'Element 24',
        },
    },
    {
        element: {
            id: 16774325,
            name: 'Element 25',
        },
    },
    {
        element: {
            id: 16774326,
            name: 'Elemen 26',
        },
    },
    {
        element: {
            id: 16774327,
            name: 'Element 27',
        },
    },
    {
        element: {
            id: 16774328,
            name: 'Element 28',
        },
    },
    {
        element: {
            id: 16774329,
            name: 'Element 29',
        },
    },
    {
        element: {
            id: 16774330,
            name: 'Element 30',
        },
    },
    {
        element: {
            id: 16774331,
            name: 'Element 31',
        },
    },
];

export default fakeElements;
