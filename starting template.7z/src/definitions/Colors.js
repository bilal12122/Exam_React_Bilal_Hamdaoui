const Colors = {
    mainGreen: '#6b9c68',
};

export default Colors;
