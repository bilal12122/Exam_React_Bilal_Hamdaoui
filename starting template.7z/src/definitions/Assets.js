import iconError from '../../assets/error.png';
import iconFav from '../../assets/favFull.png'
import iconFavEmty from '../../assets/favEmpty.png'

const Assets = {
    icons: {
        error: iconError,
        fav : iconFav,
        emty: iconFavEmty,
    },
};

export default Assets;
